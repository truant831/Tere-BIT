====================================
       PASSWORD HINT
====================================

To extract the files, you need to unlock 1337 layers.

Each layer is password-protected.

HINT: The password for each layer is its NUMBER.

Examples:
  - layer_1.zip    → password: 1
  - layer_2.zip    → password: 2
  - layer_42.zip   → password: 42
  - layer_1337.zip → password: 1337

Good luck!

====================================